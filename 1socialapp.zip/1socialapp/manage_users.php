<?php
session_start();
require 'db.php';

if (!isset($_SESSION["admin_id"])) {
    header("Location: admin_login.php");
    exit;
}

if (isset($_POST["id"], $_POST["action"])) {
    $id = (int)$_POST["id"];
    $action = $_POST["action"];

    if (in_array($action, ["block", "unblock"], true)) {
        $block = ($action === "block") ? 1 : 0;

        $stmt = $conn->prepare("UPDATE users SET block=? WHERE id=?");
        $stmt->bind_param("ii", $block, $id);
        $stmt->execute();
    }

    header("Location: manage_users.php");
    exit;
}

$result = $conn->query(
    "SELECT id,username,name,email,city,block,profile_image
     FROM users ORDER BY id"
);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Users</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container wide">
    <div class="topbar">
        <h2>Manage Users</h2>
        <a class="button secondary" href="admin_home.php">Home</a>
    </div>

    <div class="card table-card">
        <div class="table-wrap">
        <table>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Name</th>
                <th>Email</th>
                <th>City</th>
                <th>Status</th>
                <th>Profile</th>
                <th>Action</th>
            </tr>

            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= (int)$row["id"] ?></td>
                <td><?= htmlspecialchars($row["username"]) ?></td>
                <td><?= htmlspecialchars($row["name"]) ?></td>
                <td><?= htmlspecialchars($row["email"]) ?></td>
                <td><?= htmlspecialchars($row["city"]) ?></td>
                <td>
                    <?php if ($row["block"]): ?>
                        <span class="badge blocked">Blocked</span>
                    <?php else: ?>
                        <span class="badge active">Active</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if ($row["profile_image"]): ?>
                        <img class="thumb"
                             src="uploads/<?= htmlspecialchars($row["profile_image"]) ?>"
                             alt="Profile">
                    <?php else: ?>
                        No Image
                    <?php endif; ?>
                </td>
                <td>
                    <form method="post">
                        <input type="hidden" name="id" value="<?= (int)$row["id"] ?>">
                        <?php if ($row["block"]): ?>
                            <button class="small-btn success"
                                    name="action" value="unblock">Unblock</button>
                        <?php else: ?>
                            <button class="small-btn danger"
                                    name="action" value="block">Block</button>
                        <?php endif; ?>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
        </div>
    </div>
</div>
</body>
</html>