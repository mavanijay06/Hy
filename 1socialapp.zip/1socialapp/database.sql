CREATE DATABASE IF NOT EXISTS `1socialapp`
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE `1socialapp`;

CREATE TABLE IF NOT EXISTS admin (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    mobile VARCHAR(15),
    city VARCHAR(80) NOT NULL,
    profile_image VARCHAR(255),
    block TINYINT(1) NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS friends (
    id INT PRIMARY KEY AUTO_INCREMENT,
    userid INT NOT NULL,
    friend_userid INT NOT NULL,
    status ENUM('pending','accepted','ignored') NOT NULL DEFAULT 'pending',
    FOREIGN KEY (userid) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (friend_userid) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_friend_pair(userid, friend_userid)
);

INSERT INTO admin (username, password)
SELECT 'admin', '$2y$12$E6Qa7NR5A7sgYB1CKxA.3eyL9M7kdT/AdXdLv.1H50F0rcqmAekZy'
WHERE NOT EXISTS (
    SELECT 1 FROM admin WHERE username='admin'
);

/*
Demo:
1. Register two users with the same city.
2. Check their IDs in users table.
3. Example if User 1 and User 2 exist:

INSERT INTO friends(userid, friend_userid, status)
VALUES (2, 1, 'pending');

Then login as User 1 and open Friends.
*/