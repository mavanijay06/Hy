<?php
session_start();
require 'db.php';

if (!isset($_SESSION["captcha"])) {
    $_SESSION["captcha"] = rand(1000, 9999);
}

$msg = "";
$msgType = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $captcha = (int)($_POST["captcha"] ?? 0);

    if ($captcha !== (int)$_SESSION["captcha"]) {
        $msg = "Invalid CAPTCHA.";
        $msgType = "error";
    } else {
        $username = trim($_POST["username"] ?? "");
        $passwordRaw = $_POST["password"] ?? "";
        $name = trim($_POST["name"] ?? "");
        $email = trim($_POST["email"] ?? "");
        $mobile = trim($_POST["mobile"] ?? "");
        $city = trim($_POST["city"] ?? "");

        $password = password_hash($passwordRaw, PASSWORD_DEFAULT);
        $imageName = "";

        if (
            isset($_FILES["profile_image"]) &&
            $_FILES["profile_image"]["error"] !== UPLOAD_ERR_NO_FILE
        ) {
            if ($_FILES["profile_image"]["error"] !== UPLOAD_ERR_OK) {
                $msg = "Profile image upload failed.";
                $msgType = "error";
            } else {
                $allowed = ["jpg", "jpeg", "png", "gif"];
                $ext = strtolower(
                    pathinfo($_FILES["profile_image"]["name"], PATHINFO_EXTENSION)
                );

                if (!in_array($ext, $allowed, true)) {
                    $msg = "Only JPG, JPEG, PNG and GIF files are allowed.";
                    $msgType = "error";
                } elseif ($_FILES["profile_image"]["size"] > 2 * 1024 * 1024) {
                    $msg = "Profile image must be 2 MB or smaller.";
                    $msgType = "error";
                } else {
                    if (!is_dir("uploads")) {
                        mkdir("uploads", 0755, true);
                    }

                    $imageName = uniqid("profile_", true) . "." . $ext;

                    if (!move_uploaded_file(
                        $_FILES["profile_image"]["tmp_name"],
                        "uploads/" . $imageName
                    )) {
                        $msg = "Could not save profile image.";
                        $msgType = "error";
                        $imageName = "";
                    }
                }
            }
        }

        if ($msg === "") {
            $stmt = $conn->prepare(
                "INSERT INTO users
                (username,password,name,email,mobile,city,profile_image)
                VALUES(?,?,?,?,?,?,?)"
            );

            $stmt->bind_param(
                "sssssss",
                $username,
                $password,
                $name,
                $email,
                $mobile,
                $city,
                $imageName
            );

            if ($stmt->execute()) {
                $msg = "Registration successful. You can now login.";
                $msgType = "success";

                $_POST = [];
            } else {
                if ($imageName && file_exists("uploads/" . $imageName)) {
                    unlink("uploads/" . $imageName);
                }

                $msg = "Registration failed. Username or email may already exist.";
                $msgType = "error";
            }
        }
    }

    $_SESSION["captcha"] = rand(1000, 9999);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>User Registration</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="center-page">
<div class="card form-card">
    <h2>User Registration</h2>

    <?php if ($msg): ?>
        <div class="message <?= $msgType ?>">
            <?= htmlspecialchars($msg) ?>
        </div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">
        <label>Username</label>
        <input name="username" required>

        <label>Password</label>
        <input type="password" name="password" required>

        <label>Name</label>
        <input name="name" required>

        <label>Email</label>
        <input type="email" name="email" required>

        <label>Mobile</label>
        <input name="mobile">

        <label>City</label>
        <input name="city" required>

        <label>Profile Picture</label>
        <input type="file" name="profile_image"
               accept=".jpg,.jpeg,.png,.gif">

        <div class="captcha-box">
            CAPTCHA: <strong><?= (int)$_SESSION["captcha"] ?></strong>
        </div>

        <label>Enter CAPTCHA</label>
        <input type="number" name="captcha" required>

        <button type="submit">Register</button>
    </form>

    <p class="center">
        Already registered?
        <a href="login.php">Login</a>
    </p>
</div>
</body>
</html>