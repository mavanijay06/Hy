<?php
session_start();
require 'db.php';

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$currentUser = (int)$_SESSION["user_id"];

/* Check logged-in user and blocking status */
$stmt = $conn->prepare(
    "SELECT id, city FROM users WHERE id=? AND block=0"
);
$stmt->bind_param("i", $currentUser);
$stmt->execute();

$me = $stmt->get_result()->fetch_assoc();

if (!$me) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit;
}

$city = $me["city"];

/*
 * Accept / Ignore:
 * A received request is stored as:
 * sender(userid) -> receiver(friend_userid)
 */
if (isset($_POST["action"], $_POST["friend_userid"])) {
    $friendUser = (int)$_POST["friend_userid"];
    $action = $_POST["action"];

    if (
        in_array($action, ["accepted", "ignored"], true) &&
        $friendUser !== $currentUser
    ) {
        /* First look for a pending request sent TO current user */
        $check = $conn->prepare(
            "SELECT id
             FROM friends
             WHERE userid=?
             AND friend_userid=?
             AND status='pending'"
        );

        $check->bind_param("ii", $friendUser, $currentUser);
        $check->execute();

        $existing = $check->get_result()->fetch_assoc();

        if ($existing) {
            $update = $conn->prepare(
                "UPDATE friends SET status=? WHERE id=?"
            );

            $update->bind_param("si", $action, $existing["id"]);
            $update->execute();

            /*
             * For accepted friendship, create the reverse row
             * so both users can see each other in Friends List.
             */
            if ($action === "accepted") {
                $reverse = $conn->prepare(
                    "SELECT id FROM friends
                     WHERE userid=? AND friend_userid=?"
                );

                $reverse->bind_param(
                    "ii",
                    $currentUser,
                    $friendUser
                );

                $reverse->execute();

                if (!$reverse->get_result()->fetch_assoc()) {
                    $insertReverse = $conn->prepare(
                        "INSERT INTO friends
                         (userid, friend_userid, status)
                         VALUES (?, ?, 'accepted')"
                    );

                    $insertReverse->bind_param(
                        "ii",
                        $currentUser,
                        $friendUser
                    );

                    $insertReverse->execute();
                }
            }
        } else {
            /*
             * Section A:
             * Current user sends a new friendship request.
             */
            $checkExisting = $conn->prepare(
                "SELECT id,status
                 FROM friends
                 WHERE userid=? AND friend_userid=?"
            );

            $checkExisting->bind_param(
                "ii",
                $currentUser,
                $friendUser
            );

            $checkExisting->execute();

            $rowExisting = $checkExisting->get_result()->fetch_assoc();

            if (!$rowExisting) {
                $insert = $conn->prepare(
                    "INSERT INTO friends
                     (userid, friend_userid, status)
                     VALUES (?, ?, ?)"
                );

                $insert->bind_param(
                    "iis",
                    $currentUser,
                    $friendUser,
                    $action
                );

                $insert->execute();
            }
        }
    }

    header("Location: friends.php");
    exit;
}

/* Section A: Same-city users without pending/accepted relation */
$stmt = $conn->prepare(
    "SELECT u.id,u.name,u.email,u.city
     FROM users u
     WHERE u.city=?
     AND u.id<>?
     AND u.block=0
     AND NOT EXISTS (
         SELECT 1
         FROM friends f
         WHERE
         (
             f.userid=? AND f.friend_userid=u.id
         )
         OR
         (
             f.userid=u.id AND f.friend_userid=?
         )
         AND f.status IN ('pending','accepted')
     )
     ORDER BY u.name"
);

$stmt->bind_param(
    "siii",
    $city,
    $currentUser,
    $currentUser,
    $currentUser
);

$stmt->execute();
$sameCity = $stmt->get_result();

/* Section B: Pending requests received */
$stmt = $conn->prepare(
    "SELECT f.id,u.id AS userid,u.name,u.city
     FROM friends f
     JOIN users u ON u.id=f.userid
     WHERE f.friend_userid=?
     AND f.status='pending'
     AND u.block=0
     ORDER BY u.name"
);

$stmt->bind_param("i", $currentUser);
$stmt->execute();
$requests = $stmt->get_result();

/* Section C: Accepted friends */
$stmt = $conn->prepare(
    "SELECT u.id,u.name,u.city
     FROM friends f
     JOIN users u ON u.id=f.friend_userid
     WHERE f.userid=?
     AND f.status='accepted'
     AND u.block=0
     ORDER BY u.name"
);

$stmt->bind_param("i", $currentUser);
$stmt->execute();
$friends = $stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Friends</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <div class="topbar">
        <h2>Friends</h2>
        <a class="button secondary" href="user_home.php">Home</a>
    </div>

    <div class="card">
        <h3>Section A — Users from the Same City</h3>

        <?php if ($sameCity->num_rows > 0): ?>
            <?php while ($row = $sameCity->fetch_assoc()): ?>
                <div class="friend-row">
                    <div>
                        <strong><?= htmlspecialchars($row["name"]) ?></strong>
                        <span>(<?= htmlspecialchars($row["city"]) ?>)</span>
                    </div>

                    <form method="post">
                        <input type="hidden"
                               name="friend_userid"
                               value="<?= (int)$row["id"] ?>">

                        <button class="small-btn success"
                                name="action"
                                value="accepted">
                            Accept
                        </button>

                        <button class="small-btn danger"
                                name="action"
                                value="ignored">
                            Ignore
                        </button>
                    </form>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p class="empty">No same-city users found.</p>
        <?php endif; ?>
    </div>

    <div class="card">
        <h3>Section B — New Requests</h3>

        <?php if ($requests->num_rows > 0): ?>
            <?php while ($row = $requests->fetch_assoc()): ?>
                <div class="friend-row">
                    <div>
                        <strong><?= htmlspecialchars($row["name"]) ?></strong>
                        <span>(<?= htmlspecialchars($row["city"]) ?>)</span>
                    </div>

                    <form method="post">
                        <input type="hidden"
                               name="friend_userid"
                               value="<?= (int)$row["userid"] ?>">

                        <button class="small-btn success"
                                name="action"
                                value="accepted">
                            Accept
                        </button>

                        <button class="small-btn danger"
                                name="action"
                                value="ignored">
                            Ignore
                        </button>
                    </form>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p class="empty">No new requests.</p>
        <?php endif; ?>
    </div>

    <div class="card">
        <h3>Section C — Friends List</h3>

        <?php if ($friends->num_rows > 0): ?>
            <?php while ($row = $friends->fetch_assoc()): ?>
                <div class="friend-row">
                    <div>
                        <strong><?= htmlspecialchars($row["name"]) ?></strong>
                        <span>- <?= htmlspecialchars($row["city"]) ?></span>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p class="empty">No accepted friends.</p>
        <?php endif; ?>
    </div>

    <a href="user_home.php">Back to Home</a>
</div>
</body>
</html>