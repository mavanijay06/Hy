<?php
session_start();
require 'db.php';

if (isset($_SESSION["user_id"])) {
    header("Location: user_home.php");
    exit;
}

$msg = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = trim($_POST["username"] ?? "");
    $password = $_POST["password"] ?? "";

    $stmt = $conn->prepare(
        "SELECT id,username,password,block
         FROM users WHERE username=?"
    );

    $stmt->bind_param("s", $username);
    $stmt->execute();

    $user = $stmt->get_result()->fetch_assoc();

    if ($user && password_verify($password, $user["password"])) {
        if ((int)$user["block"] === 1) {
            $msg = "Your account is blocked.";
        } else {
            session_regenerate_id(true);

            $_SESSION["user_id"] = $user["id"];
            $_SESSION["username"] = $user["username"];

            header("Location: user_home.php");
            exit;
        }
    } else {
        $msg = "Invalid username or password.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>User Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="center-page">
<div class="card small-card">
    <h2>User Login</h2>

    <?php if ($msg): ?>
        <div class="message error"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <form method="post">
        <label>Username</label>
        <input name="username" required>

        <label>Password</label>
        <input type="password" name="password" required>

        <button type="submit">Login</button>
    </form>

    <p class="center">
        New user?
        <a href="register.php">Register</a>
    </p>
</div>
</body>
</html>