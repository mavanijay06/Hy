<?php
session_start();
require 'db.php';

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$stmt = $conn->prepare(
    "SELECT name,email,mobile,city,profile_image
     FROM users
     WHERE id=? AND block=0"
);

$stmt->bind_param("i", $_SESSION["user_id"]);
$stmt->execute();

$user = $stmt->get_result()->fetch_assoc();

if (!$user) {
    session_unset();
    session_destroy();

    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Profile</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container profile-container">
    <div class="card profile-card">
        <h2>My Profile</h2>

        <?php if ($user["profile_image"]): ?>
            <img class="profile-image"
                 src="uploads/<?= htmlspecialchars($user["profile_image"]) ?>"
                 alt="Profile">
        <?php else: ?>
            <div class="profile-placeholder">No Image</div>
        <?php endif; ?>

        <div class="profile-info">
            <p><strong>Name:</strong> <?= htmlspecialchars($user["name"]) ?></p>
            <p><strong>Email:</strong> <?= htmlspecialchars($user["email"]) ?></p>
            <p><strong>Mobile:</strong> <?= htmlspecialchars($user["mobile"] ?? "") ?></p>
            <p><strong>City:</strong> <?= htmlspecialchars($user["city"]) ?></p>
        </div>

        <a class="button" href="user_home.php">Home</a>
    </div>
</div>
</body>
</html>