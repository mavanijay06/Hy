1SOCIALAPP - PHP SOCIAL NETWORK

DATABASE
--------
Database name: 1socialapp
MySQL username: root
MySQL password: empty

ADMIN LOGIN
-----------
Username: admin
Password: admin123

SETUP
-----
1. Copy the 1socialapp folder into:
   C:\xampp\htdocs\

2. Start Apache and MySQL from XAMPP.

3. Open phpMyAdmin.

4. Import database.sql.

5. Open:
   http://localhost/1socialapp/admin_login.php

USER FLOW
---------
register.php
    |
    v
login.php
    |
    v
user_home.php
    |
    +--> profile.php
    |
    +--> friends.php
    |
    +--> logout.php

ADMIN FLOW
----------
admin_login.php
    |
    v
admin_home.php
    |
    v
manage_users.php
    |
    v
admin_logout.php

PROFILE IMAGES
--------------
Uploaded images are stored in:
uploads/

FRIENDS DEMO
------------
Register two users with the same city.

Then in phpMyAdmin:
INSERT INTO friends(userid, friend_userid, status)
VALUES (2, 1, 'pending');

Login as user 1 and open Friends.

NOTE
----
The source journal had a missing semicolon in friends.php and an
incorrect received-request lookup. Those issues are fixed in this ZIP.
The database name has been changed from social_app to 1socialapp.

link-

http://localhost/phpmyadmin/
http://localhost/1socialapp/filename/
