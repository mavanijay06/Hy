<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>User Home</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <div class="topbar">
        <h2>Social Network</h2>
        <a class="button danger" href="logout.php">Logout</a>
    </div>

    <div class="card welcome-card">
        <h2>Welcome <?= htmlspecialchars($_SESSION["username"]) ?>!</h2>
        <p>Choose an option below.</p>

        <div class="actions">
            <a class="button" href="profile.php">View Profile</a>
            <a class="button" href="friends.php">Friends</a>
            <a class="button danger" href="logout.php">Logout</a>
        </div>
    </div>
</div>
</body>
</html>