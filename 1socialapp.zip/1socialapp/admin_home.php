<?php
session_start();

if (!isset($_SESSION["admin_id"])) {
    header("Location: admin_login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Home</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <div class="topbar">
        <h2>Admin Dashboard</h2>
        <a class="button danger" href="admin_logout.php">Logout</a>
    </div>

    <div class="card">
        <h3>Welcome, <?= htmlspecialchars($_SESSION["admin_username"]) ?>!</h3>
        <p>Manage registered users from here.</p>
        <a class="button" href="manage_users.php">Manage Users</a>
    </div>
</div>
</body>
</html>